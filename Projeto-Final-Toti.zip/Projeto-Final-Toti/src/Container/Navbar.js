import React from "react";
import "../CSS/Navbar.css";
import logo from "../Imgs/logo.png";
import Header from "../Imgs/Header-img.jpg";
import { Link } from "react-router-dom";
var Carousel = require("react-responsive-carousel").Carousel;

const Navbar = ({ isNav }) => {
  return (
    <div id="header">
      <div className="Navbar">
        <div>
          <img id="logo" src={logo} />
        </div>
        <div>
          <ul>
            <li>Home</li>
            <li>
              <a href="/caros">Cadastrar Carros</a>
            </li>
            {/* <li>Carrinho</li> */}
          </ul>
        </div>
      </div>

      <div id="header-content">
        <Carousel
          autoPlay={true}
          infiniteLoop={true}
          showThumbs={false}
          showIndicators={false}
          showStatus={false}
          showArrows={false}
          className="carousel"
        >
          <div>
            <img src="https://cdn.pixabay.com/photo/2016/11/22/23/44/porsche-1851246_1280.jpg " />
          </div>
          <div>
            <img src="https://cdn.pixabay.com/photo/2016/12/03/18/57/car-1880381_1280.jpg" />
          </div>
          <div>
            <img src="https://svg-image.s3.amazonaws.com/south-honda/061-0221-SHO873/slider1.jpg" />
          </div>
        </Carousel>
        <span id="propaganda">
          <h1>
            Encontre aqui
            <br />
            seu próximo carro
          </h1>
          <p>
            Escolhe seu carro aqui e a gente leva até você.
            <br />E se pensar em financiamento,
            <br />
            faça tudo online simples e rápido.
          </p>
        </span>
        {/* <img id="header-img" src={Header} /> */}
      </div>
    </div>
  );
};

export default Navbar;

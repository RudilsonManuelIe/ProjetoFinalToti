import React, { useEffect } from "react";
import Form from "./Form";

const Table = ({ carros, postCarro, updateCarro, deleteCarro }) => {
  const showUpdateCarro = (id) => {
    const form = document.getElementsByClassName(`show-form-${id}`);
    form[0].classList.toggle("hide-form");
  };

  const Row = ({ carro }) => {
    return (
      <>
        <div className="row-table">
          {/* <div>{carro.imagem}</div> */}
          <div>{carro.marca}</div>
          <div>{carro.modelo}</div>
          <div>{carro.preco}</div>
          <div>{carro.ano}</div>
          <div className="buttons">
            <button onClick={() => showUpdateCarro(carro.id)}>Editar</button>
            <button onClick={() => deleteCarro(carro.id)}>Apagar</button>
          </div>
        </div>
        <div className={`hide-form show-form-${carro.id}`}>
          <Form
            carroData={carro}
            postCarro={postCarro}
            updateCarro={updateCarro}
          />
        </div>
      </>
    );
  };

  return (
    <div className="table">
      <div className="titles">
        {/* <div>Imagem</div> */}
        <div>Marca</div>
        <div>Modelo</div>
        <div>preco</div>
        <div>ano</div>
        <div>Acao</div>
      </div>
      <div className="rows">
        {carros && carros.map((u) => <Row carro={u} key={u.id} />)}
      </div>
    </div>
  );
};

export default Table;

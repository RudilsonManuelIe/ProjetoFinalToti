import React, { useState, useEffect } from "react";
const Form = ({ carroData = {}, postCarro, updateCarro }) => {
  const [carro, setCarro] = useState({
    imagem: "",
    marca: "",
    preco: "",
    modelo: "",
    ano: "",
    id: 0,
  });

  useEffect(() => {
    // Sempre eh chamado ao iniciar a tela e tambem eh chamdo se ouvi mudanca nos valores
    if (carroData.id !== 0) {
      setCarro(carroData); // adicina objecto carro
    }
  }, []);

  const handleValue = (e) => {
    const name = e.target.name;
    const value = e.target.value;

    setCarro({ ...carro, [name]: value });

    //nome: e.target.name;  carro.imagem = imagem   //valor: e.target.value
    // carro {imagem , marca, preco .. }
  };

  const submitcarro = (e) => {
    e.preventDefault(); // verifica so se nao tem repeticao

    if (carro.id === 0) return; // se o carro tiver identificador = 0 retorna sem fazer nada

    // se o tiver id eh para atualizar caso contrario criamos um novo carro
    if (carroData.id) {
      updateCarro(carroData.id, carro);
    } else {
      postCarro(carro);
      setCarro({});
    }
  };

  return (
    <form onSubmit={submitcarro} className="row-form">
      <input
        type="text"
        name="imagem"
        value={carro.imagem || ""}
        placeholder="https://"
        onChange={handleValue}
        required
      />
      <input
        type="text"
        name="marca"
        value={carro.marca || ""}
        placeholder="Marca do carro"
        onChange={handleValue}
        required
      />
      <input
        type="text"
        name="modelo"
        value={carro.modelo || ""}
        placeholder="Modelo"
        onChange={handleValue}
        required
      />
      <input
        type="text"
        name="preco"
        value={carro.preco || ""}
        placeholder="R$1000"
        onChange={handleValue}
        required
      />
      <input
        type="text"
        name="ano"
        value={carro.ano || ""}
        placeholder="2022"
        onChange={handleValue}
        required
      />
      <input
        className="btn-submit"
        type="submit"
        value={`${!carroData.id ? "Addicionar novo carro" : "Salvar carro"}`}
      />
    </form>
  );
};

export default Form;

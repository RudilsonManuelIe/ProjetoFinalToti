import React, { useState, useEffect, useCallback } from "react";
import { httpHelper } from "../Helper/HttpHelper";
import "../CSS/Filtro.css";
import Cards from "./Cards";

const Filtro = ({ datos = [] }) => {
  const url = "http://localhost:5000/Carros";
  const api = httpHelper();

  const [search, setSearch] = useState({
    marca: "",
    preco: "",
    modelo: "",
    ano: "",
  });
  const [carros, setCarros] = useState({});
  const [carrosFiltrados, setCarrosFiltrados] = useState({});

  const pesquisar = (e) => {
    const name = e.target.name;
    const value = e.target.value;

    setSearch({ ...search, [name]: value });
  };

  useEffect(() => {
    getCarros();
  }, []);

  const handleSearch = (e) => {
    e.preventDefault();

    const filtro = carros.filter((c) => {
      return (
        c.marca === search.marca ||
        c.modelo === search.modelo ||
        c.preco === search.preco ||
        c.ano === search.ano
      );
    });

    setCarrosFiltrados(filtro);
  };

  const getCarros = useCallback(() => {
    api
      .get(`${url}`)
      .then((res) => {
        setCarros(res);
      })
      .catch((err) => console.log(err));
  }, [carros]);

  return (
    <>
      <form id="form" onSubmit={handleSearch}>
        <div id="filter-bar">
          <div id="form-control-search">
            <label htmlFor="search-bar" id="search-lable">
              O que está procurando?
            </label>
            <input
              type="text"
              placeholder="pesquisa"
              name="marca"
              value={search.marca || ""}
              onChange={pesquisar}
              id="search-bar"
            />
            <button className="btn-search" type="submit">
              Pesquisar
            </button>
          </div>
          <div id="form-control">
            <label htmlFor="preço">Preço:</label>
            <input
              type="text"
              name="preco"
              placeholder="R$1000"
              id="preço"
              value={search.preco || ""}
              onChange={pesquisar}
            />
          </div>
          <div id="form-control">
            <label htmlFor="marca">Ano:</label>
            <input
              type="text"
              name="ano"
              placeholder="2022"
              id="ano"
              value={search.ano || ""}
              onChange={pesquisar}
            />
          </div>
          <div id="form-control">
            <label htmlFor="marca">Marca:</label>
            <input
              type="text"
              name="marca"
              placeholder="marca do carro"
              id="marca"
              value={search.marca || ""}
              onChange={pesquisar}
            />
          </div>
          <div id="form-control">
            <label htmlFor="marca">Modelo:</label>
            <input
              type="text"
              name="modelo"
              placeholder="marca do carro"
              id="marca"
              value={search.modelo || ""}
              onChange={pesquisar}
            />
          </div>
        </div>
      </form>
      {carrosFiltrados && <Cards carros={carrosFiltrados} />}
    </>
  );
};

export default Filtro;

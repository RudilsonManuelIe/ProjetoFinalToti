import React from "react";
import Form from "./Crud/Form";

function CadastrarCarros() {
  return (
    <div>
      <Form />
    </div>
  );
}

export default CadastrarCarros;

import React, { useCallback } from "react";
import { httpHelper } from "../Helper/HttpHelper";
import Form from "./Crud/Form";
import "../CSS/Cards.css";

import CadastrarCarros from "./CadastrarCarros";

const Cards = ({ carros = [] }) => {
  const showUpdateCarro = (id) => {
    const form = document.getElementsByClassName(`show-form-${id}`);
    form[0].classList.toggle("hide-form");
  };
  const url = "http://localhost:5000/Carros";
  const api = httpHelper();

  const updateCarro = (id, carro) => {
    // EDITAR CARRO
    api
      .put(`${url}/${id}`, { body: carro })
      .then((res) => getCarros())
      .catch((err) => console.log(err));
  };

  const deleteCarro = (id) => {
    // APAGAR CARRO
    api
      .del(`${url}/${id}`, {})
      .then((res) => getCarros())
      .catch((err) => console.log(err));
  };

  const getCarros = useCallback(() => {
    // PEGAR CARROS
    api
      .get(`${url}`)
      .then((res) => {
        //setCarros(res);
        window.location.reload();
      })
      .catch((err) => console.log(err));
  }, [carros]);
  return (
    <>
      <div className="card-row">
        {Array.isArray(carros)
          ? carros.map((carro, index) => (
              <>
                <div key={index} className="col mb-4">
                  <div className="card">
                    <div className="Imagem">
                      <img src={carro.imagem} alt="" />
                    </div>
                    <div className="card-body">
                      <h3 className="titulo"> {carro.marca}</h3>
                      <h4 className="subtitulo">Modelo: {carro.modelo}</h4>
                      <p className="text">Ano: {carro.ano}</p>
                      <p className="text-preco">Preço:R${carro.preco}</p>
                      <div className="btn">
                        <button
                          onClick={() => showUpdateCarro(carro.id)}
                          className="btn-uptade"
                        >
                          Atualizar
                        </button>
                        <button
                          onClick={() => deleteCarro(carro.id)}
                          className="btn-delete"
                        >
                          Remover
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
                <div
                  className={`hide-form show-form-${carro.id} update-bg-form`}
                >
                  <Form carroData={carro} updateCarro={updateCarro} />
                </div>
              </>
            ))
          : null}
      </div>
    </>
  );
};

export default Cards;

import React from "react";

function Carrinho() {
    return(
        <div>
            Carrinho
        </div>
    )
}

export default Carrinho;
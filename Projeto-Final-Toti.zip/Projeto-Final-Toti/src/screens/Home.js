import React from "react";

import Navbar from "../Container/Navbar";
import Filtro from "../Container/Filtro";
import Cards from "../Container/Cards";
import Api from "../Api";
import Formulario from "../Container/Formulario";

const Home = () => {
  return (
    <div>
      <Navbar />

      <Filtro />
      <Cards />
      <Api />
      <Formulario />
    </div>
  );
};

export default Home;

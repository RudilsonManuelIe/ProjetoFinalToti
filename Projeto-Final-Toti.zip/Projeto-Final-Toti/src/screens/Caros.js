import React, { useState, useEffect, useCallback } from "react";
import Form from "../Container/Crud/Form";
import Table from "../Container/Crud/Table";
import { httpHelper } from "../Helper/HttpHelper";
import { SunIcon } from "../Assets/Icons";
import "../CSS/Caros.css";

const Caros = () => {
  const [carros, setCarros] = useState();

  const url = "http://localhost:5000/Carros";
  const api = httpHelper();

  useEffect(() => {
    getCarros();
  }, []);

  const postCarro = (carro) => {
    // CADASTRAR CARRO
    api
      .post(`${url}`, { body: carro })
      .then((res) => getCarros())
      .catch((err) => console.log(err));
  };

  const updateCarro = (id, carro) => {
    // EDITAR CARRO
    api
      .put(`${url}/${id}`, { body: carro })
      .then((res) => getCarros())
      .catch((err) => console.log(err));
  };

  const deleteCarro = (id) => {
    // APAGAR CARRO
    api
      .del(`${url}/${id}`, {})
      .then((res) => getCarros())
      .catch((err) => console.log(err));
  };

  const getCarros = useCallback(() => {
    // PEGAR CARROS
    api
      .get(`${url}`)
      .then((res) => {
        setCarros(res);
      })
      .catch((err) => console.log(err));
  }, [carros]);

  if (!carros) {
    console.log("Nao tem carros");
    return null;
  }

  return (
    <>
      <header>
        <div className="header__content">
          <div className="logo">
            <SunIcon />
            <strong>
              <a href="/">CARROS CRUD</a>
            </strong>
          </div>
        </div>
      </header>
      <main>
        <h3>Novo Carro</h3>
        <Form postCarro={postCarro} />
        <div className="all-users">
          <h3>Todos os Carros</h3>
          <Table
            carros={carros}
            setCarros={setCarros}
            postCarro={postCarro}
            updateCarro={updateCarro}
            deleteCarro={deleteCarro}
          />
        </div>
      </main>
    </>
  );
};

export default Caros;

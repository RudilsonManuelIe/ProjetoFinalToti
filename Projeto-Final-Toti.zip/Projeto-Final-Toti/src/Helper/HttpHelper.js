export const httpHelper = () => {
  // criar o cabecalho para fetch
  const customFetch = async (url, options = {}) => {
    const defaultMethod = "GET";
    const defaultHeaders = {
      // cabecalho para request
      "Content-Type": "application/json",
      Accept: "application/json",
    };

    const controller = new AbortController(); // objecto cotroller (puro classe de js para request)
    options.signal = controller.signal;

    options.method = options.method || defaultMethod; // tipo de metodo
    options.headers = options.headers // cabecalho (tipo de json, aceitar)
      ? { ...defaultHeaders, ...options.headers }
      : defaultHeaders;

    options.body = JSON.stringify(options.body) || false; // o corpo da resposta do server ' {} '
    if (!options.body) delete options.body; // se o corpo do request nao existir apaga o corpo da opcao

    // tempo para realizacao de request
    setTimeout(() => {
      controller.abort();
    }, 3000);

    try {
      // tenta fazer request uma por uma
      const response = await fetch(url, options);
      return await response.json(); // retorna a resposta (corpo)
    } catch (err) {
      return err; // se acontecer um erro no request
    }
  };

  //url => e um link como (http//api/v1/carros)
  // options => e a opcao passada (objecto) opcao = { metodo = post , sinal = signal , corpo = body}
  const get = (url, options = {}) => customFetch(url, options);

  const post = (url, options) => {
    // CRIAR
    options.method = "POST";
    return customFetch(url, options);
  };

  const put = (url, options) => {
    // EDITAR
    options.method = "PUT";
    return customFetch(url, options);
  };

  const del = (url, options) => {
    // DELETAR
    options.method = "DELETE";
    return customFetch(url, options);
  };

  return {
    get,
    post,
    put,
    del,
  };
};

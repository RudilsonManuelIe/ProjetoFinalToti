import React from "react";
import Navbar from "./Container/Navbar";
import Filtro from "./Container/Filtro";
import Cards from "./Container/Cards";
import Api from "./Api";
import Buttons from "./Container/Buttons";
import Formulario from "./Container/Formulario";
import "./App.css";
import { BrowserRouter as Router, Link, Routes, Route } from "react-router-dom";
import Home from "./screens/Home";
import Caros from "./screens/Caros";
function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/caros" element={<Caros />} />
      </Routes>
    </Router>
  );
}

export default App;

//url Api https://parallelum.com.br/fipe/api/v1/carros/marcas/59/modelos
//http://localhost:3000/carro
